// <plugin root>/src/Resources/app/administration/src/module/sw-cms/blocks/text-image/home-hero/component/index.js
import template from './sw-cms-block-gp-achievement-list.html.twig'
import './sw-cms-block-gp-achievement-list.scss'

Shopware.Component.register('sw-cms-block-gp-achievement-list', {
	template
})