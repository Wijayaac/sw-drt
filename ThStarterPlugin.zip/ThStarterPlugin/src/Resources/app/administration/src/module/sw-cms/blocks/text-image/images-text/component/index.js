// <plugin root>/src/Resources/app/administration/src/module/sw-cms/blocks/text-image/images-text/component/index.js
import template from "./sw-cms-block-images-text.html.twig";
import "./sw-cms-block-images-text.scss";

Shopware.Component.register("sw-cms-block-images-text", {
  template,
});
