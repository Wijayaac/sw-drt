// <plugin root>/src/Resources/app/administration/src/module/sw-cms/blocks/text-image/images-text/preview/index.js
import template from "./sw-cms-preview-images-text.html.twig";
import "./sw-cms-preview-images-text.scss";

Shopware.Component.register("sw-cms-preview-images-text", {
  template,
});
