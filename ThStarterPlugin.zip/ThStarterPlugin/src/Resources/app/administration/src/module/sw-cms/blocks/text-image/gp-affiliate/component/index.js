// <plugin root>/src/Resources/app/administration/src/module/sw-cms/blocks/text-image/gp-affiliate/component/index.js
import template from './sw-cms-block-gp-affiliate.html.twig'
import './sw-cms-block-gp-affiliate.scss'

Shopware.Component.register('sw-cms-block-gp-affiliate', {
	template
})