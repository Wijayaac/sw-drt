// <plugin root>/src/Resources/app/administration/src/module/sw-cms/blocks/text-image/gp-company-discount/preview/index.js
import template from './sw-cms-preview-gp-affiliate.html.twig'
import './sw-cms-preview-gp-affiliate.scss'

Shopware.Component.register('sw-cms-preview-gp-affiliate', {
	template
})